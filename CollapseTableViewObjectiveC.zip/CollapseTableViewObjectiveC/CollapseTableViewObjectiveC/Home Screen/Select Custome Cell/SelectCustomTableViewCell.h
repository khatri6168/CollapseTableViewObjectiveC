//
//  SelectCustomTableViewCell.h
//  CollapseTableViewObjectiveC
//
//  Created by StrateCore - iMac1 on 26/07/16.
//  Copyright © 2016 StrateCore. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SelectCustomTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblName;
@property (weak, nonatomic) IBOutlet UIImageView *imgArow;
@property (weak, nonatomic) IBOutlet UIButton *btnOpen;
@property (weak, nonatomic) IBOutlet UIImageView *imageArrow;

@end
