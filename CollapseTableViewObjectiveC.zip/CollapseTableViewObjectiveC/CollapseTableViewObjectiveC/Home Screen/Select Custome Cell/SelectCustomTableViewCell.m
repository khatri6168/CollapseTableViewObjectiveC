//
//  SelectCustomTableViewCell.m
//  CollapseTableViewObjectiveC
//
//  Created by StrateCore - iMac1 on 26/07/16.
//  Copyright © 2016 StrateCore. All rights reserved.
//

#import "SelectCustomTableViewCell.h"

@implementation SelectCustomTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
