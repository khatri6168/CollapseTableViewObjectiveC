//
//  UnSelectCustomTableViewCell.h
//  CollapseTableViewObjectiveC
//
//  Created by StrateCore - iMac1 on 26/07/16.
//  Copyright © 2016 StrateCore. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UnSelectCustomTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *lblName;
@end
