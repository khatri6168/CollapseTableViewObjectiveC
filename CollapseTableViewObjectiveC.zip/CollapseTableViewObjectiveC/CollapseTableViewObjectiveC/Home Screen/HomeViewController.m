//
//  HomeViewController.m
//  CollapseTableViewObjectiveC
//
//  Created by StrateCore - iMac1 on 26/07/16.
//  Copyright © 2016 StrateCore. All rights reserved.
//

#import "HomeViewController.h"
#import "SelectCustomTableViewCell.h"
#import "UnSelectCustomTableViewCell.h"

@interface HomeViewController ()

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    // GET THE DETAILS
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"SlideMenu_Login" ofType:@"txt"];
    NSData *content = [[NSData alloc] initWithContentsOfFile:filePath];
    arrMenuList=[[NSMutableArray alloc] init];
    arrMenuList=[[NSJSONSerialization JSONObjectWithData:content options:kNilOptions error:nil] mutableCopy];
    
    /////..TABLE VIEW DELEGAT..////
    tblView.delegate=self;
    tblView.dataSource=self;
    [tblView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark - TableView Methods

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return arrMenuList.count;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    // arrDetails=[[arrMenuList objectAtIndex:self.selectIndex.section]objectForKey:@"details"];
    if (self.isOpen) {
        if (self.selectIndex.section == section) {
            return [[[arrMenuList objectAtIndex:section] objectForKey:@"details"] count]+1;
        }
    }
    return 1;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    // SET THE TABLE VIEW CELL
    if (self.isOpen&&self.selectIndex.section == indexPath.section&&indexPath.row!=0) {
        
        static NSString  *simpleTableIdentifier = @"UnSelectCustomTableViewCell";
        UnSelectCustomTableViewCell *cell = (UnSelectCustomTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        NSArray *arr=[[NSBundle mainBundle] loadNibNamed:@"UnSelectCustomTableViewCell" owner:self options:nil];
        cell=[arr objectAtIndex:0];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        cell.backgroundColor=[UIColor clearColor];
        
        NSArray *list = [[arrMenuList objectAtIndex:self.selectIndex.section] objectForKey:@"details"];
        cell.lblName.text=[list objectAtIndex:indexPath.row-1];
        
        return cell;
    }
    else
    {
        
        static NSString  *simpleTableIdentifier = @"SelectCustomTableViewCell";
        SelectCustomTableViewCell *cell = (SelectCustomTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        NSArray *arr=[[NSBundle mainBundle] loadNibNamed:@"SelectCustomTableViewCell" owner:self options:nil];
        cell=[arr objectAtIndex:0];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        cell.backgroundColor=[UIColor clearColor];
        
         // SOCIAL
       // [cell.btnLogo setImage:[[UIImage imageNamed:@"ic_social"] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate] forState:UIControlStateNormal];
        cell.lblName.textColor=[UIColor blackColor];
        cell.lblName.text=[[arrMenuList objectAtIndex:indexPath.section]objectForKey:@"name"];

        
        // SET THE BUTTON
        [cell.btnOpen addTarget:self action:@selector(butOpenSectionClicked:) forControlEvents:UIControlEventTouchUpInside];
        
        return cell;
    }
}



-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (self.isOpen&&self.selectIndex.section == indexPath.section&&indexPath.row!=0) {
        NSArray *list = [[arrMenuList objectAtIndex:self.selectIndex.section] objectForKey:@"details"];
        NSString *strName=[NSString stringWithFormat:@"Select City is : %@",[list objectAtIndex:indexPath.row-1]];
        
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:nil message:strName delegate:nil cancelButtonTitle:@"Okay" otherButtonTitles:nil];
        [alertView show];    }
}


#pragma mark COLLAPSE TABLE

- (void)didSelectCellRowFirstDo:(BOOL)firstDoInsert nextDo:(BOOL)nextDoInsert{
    self.isOpen = firstDoInsert;
    [tblView beginUpdates];
    
    int section = (int)self.selectIndex.section;
    
    SelectCustomTableViewCell *cell = (SelectCustomTableViewCell *)[tblView cellForRowAtIndexPath:self.selectIndex];
    
    
    int contentCount = (int)[[[arrMenuList objectAtIndex:self.selectIndex.section]objectForKey:@"details"] count];
    NSMutableArray* rowToInsert = [[NSMutableArray alloc] init];
    for (NSUInteger i = 1; i < contentCount + 1; i++) {
        NSIndexPath* indexPathToInsert = [NSIndexPath indexPathForRow:i inSection:section];
        [rowToInsert addObject:indexPathToInsert];
    }
    
    if (section!=self.preIndex.section) {
        [tblView deleteRowsAtIndexPaths:rowToInsert withRowAnimation:UITableViewRowAnimationTop];
        
        // ROTATE IMAGE ARRAOW UP
        cell.lblName.textColor=[UIColor blackColor];
        cell.imageArrow.image=[UIImage imageNamed:@"ic_next"];
        cell.backgroundColor=[UIColor clearColor];

       
    }
    else{
        
        if (firstDoInsert)
        {
            [tblView insertRowsAtIndexPaths:rowToInsert withRowAnimation:UITableViewRowAnimationTop];
            
            // ROTATE IMAGE ARRAOW UP
            cell.lblName.textColor=[UIColor lightGrayColor];
            cell.imageArrow.image=[UIImage imageNamed:@"ic_down"];
            cell.backgroundColor=[UIColor colorWithRed:250.0/255 green:250.0/255 blue:250.0/255 alpha:1.0f];

            
        }
        else
        {
            [tblView deleteRowsAtIndexPaths:rowToInsert withRowAnimation:UITableViewRowAnimationTop];
            
            // ROTATE IMAGE ARRAOW UP
            cell.lblName.textColor=[UIColor blackColor];
            cell.imageArrow.image=[UIImage imageNamed:@"ic_next"];
            cell.backgroundColor=[UIColor clearColor];

         
            }
    }
    
    [tblView endUpdates];
    if (nextDoInsert) {
        self.isOpen = YES;
        if (section!=self.preIndex.section){
            self.selectIndex=self.preIndex;
        }
        else{
            self.selectIndex = [tblView indexPathForSelectedRow];
        }
        
        [self didSelectCellRowFirstDo:YES nextDo:NO];
    }
    if (self.isOpen) [tblView scrollToNearestSelectedRowAtScrollPosition:UITableViewScrollPositionTop animated:YES];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.isOpen&&self.selectIndex.section == indexPath.section&&indexPath.row!=0) {
            return 50;
        }
    else{
        return 70;
    }
}

//SELECT CELL
-(void)butOpenSectionClicked :(id) sender{
    
    CGPoint touchPoint = [sender convertPoint:CGPointZero toView:tblView];
    NSIndexPath *indexPath = [tblView indexPathForRowAtPoint:touchPoint];
    
    
    self.preIndex=indexPath;
    
    if (indexPath.row == 0) {
        if ([indexPath isEqual:self.selectIndex]) {
            self.isOpen = NO;
            [self didSelectCellRowFirstDo:NO nextDo:NO];
            self.selectIndex = nil;
        }
        else
        {
            
            if (!self.selectIndex) {
                self.selectIndex = indexPath;
                [self didSelectCellRowFirstDo:YES nextDo:NO];
                
            }else
            {
                [self didSelectCellRowFirstDo:NO nextDo:YES];
            }
        }
    }
}

@end
