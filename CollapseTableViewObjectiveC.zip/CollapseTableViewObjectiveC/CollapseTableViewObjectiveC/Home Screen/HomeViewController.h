//
//  HomeViewController.h
//  CollapseTableViewObjectiveC
//
//  Created by StrateCore - iMac1 on 26/07/16.
//  Copyright © 2016 StrateCore. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>{
    NSMutableArray *arrMenuList;
    IBOutlet UITableView *tblView;
}
@property (assign)BOOL isOpen;
@property (nonatomic,retain)NSIndexPath *selectIndex,*preIndex;
@end
